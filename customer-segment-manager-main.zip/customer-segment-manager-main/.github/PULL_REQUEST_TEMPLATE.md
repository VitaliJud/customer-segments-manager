## What?
A description about what this pull request implements and its purpose. Try to be detailed and describe any technical details to simplify the job of the reviewer and the individual on production support.

## Why?
...

## Testing / Proof
...

@bigcommerce/api-client-developers
