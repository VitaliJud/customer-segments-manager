const ShopperProfiles = () => {
    return <div>TODO: Shopper Profiles Editor</div>
}

export default ShopperProfiles